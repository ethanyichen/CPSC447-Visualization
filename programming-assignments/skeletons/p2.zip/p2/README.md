# P2: Visualizing Political Leaders

Credits:
Used The class example d3-linked-charts-dispatcher