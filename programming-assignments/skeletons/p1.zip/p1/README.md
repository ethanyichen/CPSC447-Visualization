# P1: The Cost of Natural Disasters

Citation:
Followed example listener, tooltip design https://codesandbox.io/s/github/UBC-InfoVis/2021-436V-examples/tree/master/d3-linked-charts-dispatcher
Followed example row column design https://github.com/UBC-InfoVis/447-materials/blob/23Jan/case-studies/case-study_measles-and-vaccines